import express from 'express';                          //import express
const MongoClient = require('mongodb').MongoClient;     //import mongodb as client for MongoSB Server
import bodyParser from 'body-parser';                   //import body-parser to read data from HTTP message body  
const port = 8900;
const app = express();
let db;
const mongourl = 'mongodb://127.0.0.1:27017/'          //mongo url and port   
const col_name = 'userlist';

app.use(express.static(__dirname+'/public'));         //serve static content from this folder for css files 

app.use(bodyParser.urlencoded({extended:true}));      //attach body parser as middle ware
app.use(bodyParser.json());                          

app.set('view engine', 'ejs');                       //set ejs as view engine
app.set('views', './views');                         //set views folder to retreive ejs views 

// Get Data from datbase and display on index
app.get('/', (req,res)=>{
    db.collection(col_name).find().toArray((err,result) => {
        if(err) throw err;
        res.render('index.ejs',{data:result})        //render ejs file and pass data to  display 
    })
})

// Post data from ui
app.post('/addData', (req,res) => {
    db.collection(col_name)
        // In Req.body we will receive the data from the form.
        .insert(req.body, (err,result) => {
            if(err) throw err;
            console.log('data.inserted');
        })
    res.redirect('/');
})

// Delete Selected User
app.delete('/delete_user',(req,res) => {
    db.collection(col_name).findOneAndDelete({
        "name":req.body.name
    },(err,result) => {
        if (err) return res.send(500,err)
        res.send({message: 'success'})
    })
})

// Find user by name
app.post('/find_by_name',(req,res) => {
    let name = req.body.name;
    db.collection(col_name)
      .find({name:name})
      .toArray((err,result) => {
          if(err) throw err;
          res.send(result)
      })
});

// Update User
app.put('/update_user',(req,res)=>{
    db.collection(col_name)
        .findOneAndUpdate({"name":req.body.name},{
            $set:{
                name:req.body.name,
                email:req.body.email,
                phone:req.body.phone
            }
        },{
            upsert:true
        },(err,result) => {
            if(err) return res.send(err);
            res.send(result)
        })
})

// Opening Add User page
app.get('/addUser',(req,res) => {
    res.render('admin')
})

MongoClient.connect(mongourl, { useNewUrlParser: true },(err,client) => {
    if(err) throw err;
    db = client.db('march_dashboard')
    app.listen(port, ()=> {
        console.log(`Server running on port ${port}`)
    })
})