const express = require('express');                //import system defined express
const expressGraphQL = require('express-graphql'); //import system defined express-graphql
const schema = require('./schema/schema');         //import custom schema  
const port = 4800;

const app = express();

// Middle ware route to use graphQL  hosted on Express JS HTTP Endpoint
app.use('/graphql', expressGraphQL({          
    schema,                                       //provide refderence to the Schema file
    graphiql:true
}))

app.listen(port,() => {      //express server is listening on port 4800
    console.log(`listing to port ${port}`)
})