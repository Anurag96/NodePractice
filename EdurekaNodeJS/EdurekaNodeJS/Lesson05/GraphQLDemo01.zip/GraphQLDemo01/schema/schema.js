const graphql = require('graphql');          //import system defined module
const _ = require('lodash');                 //import system defined module for support to parse /search data

const {                                     //define schema/data structure types
    GraphQLObjectType,
    GraphQLString,
    GraphQLInt,
    GraphQLSchema} = graphql;

//Static Data
const users = [                           //define mock hard coded data
    {"id": "23", "firstName":"Bill", "age":20},
    {"id": "47", "firstName":"John", "age":22},
    {"id": "13", "firstName":"Andy", "age":11},
    {"id": "76", "firstName":"Kerio", "age":33}
]

// Create Schema for 'users' data as per schema defined 
const UserType = new GraphQLObjectType({
    name:'User',
    fields:{                                         //query returns id, firstname & age fields
        id: {type: GraphQLString},
        firstName: {type: GraphQLString},
        age:{type: GraphQLInt}
    }
});

//Define Root GraphQL Query to retreive 'users' data
const RootQuery = new GraphQLObjectType({
    name:'RootQueryType',
    fields:{
        user:{
            type:UserType,                    //map to the custom data model object created above
            args: {id:{type:GraphQLString}},  //pass the id to retreive data from mock "users" array 
            resolve(parentValue, args){       //resolve is fired to execute the query.
                return _.find(users,{id:args.id})  //find is ldash method to parse result
            }
        }
    }
});


//export schema
module.exports = new GraphQLSchema({
    query: RootQuery                      //queery refrenece provided 

});
