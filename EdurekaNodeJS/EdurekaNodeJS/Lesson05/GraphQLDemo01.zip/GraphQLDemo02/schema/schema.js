const graphql = require('graphql');         //import system defined graph QL
const axios = require('axios');             //import system defined axios 

const {                                     //define generic schema for 'companies' and 'users' data
    GraphQLObjectType,
    GraphQLString,
    GraphQLInt,
    GraphQLSchema,
    GraphQLList,
    GraphQLNonNull} = graphql;

//For nested 'company' data  -  graphql Schema definition
const CompanyType = new GraphQLObjectType({
    name: 'Company',
    fields:() => ({                          //data fields definition
        id: {type: GraphQLString},
        name: {type: GraphQLString},
        location: {type: GraphQLString},
        users: {
            type: new GraphQLList(UserType)
        }
    })
});

//For 'users' data & associated company -  graphql query schema definition
const UserType = new GraphQLObjectType({
    name:'User',
    fields:() => ({                       //data fields definition
        id: {type: GraphQLString}, 
        firstName: {type: GraphQLString},
        age:{type: GraphQLInt},
        company: {
            type: CompanyType,
        }
    })
});

// Root Query for Getting 'users' & 'company' data from API
const RootQuery = new GraphQLObjectType({
    name:'RootQueryType',
    fields:{
        user:{
            type:UserType,
            args: {id:{type:GraphQLString}},           // pass the  user id to  search 
            resolve(parentValue, args){     //fired to execute the query
                //node module to get data from REST API
                return axios.get(`http://localhost:8900/users/${args.id}`)
                .then(resp => resp.data)
            }
        },
        company:{
            type:CompanyType,
            args:{id:{type:GraphQLString}},         //pass the compant id to serach
            resolve(parentValue, args){
                //node module to get data from REST API
                return axios.get(`http://localhost:8900/companies/${args.id}`)
                .then(resp => resp.data)
            }
        }
    }
});

// Mutation - used for CRU - insert update delete operations. GraphQL Data Type.
const mutation = new GraphQLObjectType({
    name:'Mutation',
    fields: {
        addUser: {                           //function name to call in GrpahQL IDE / Playground
            type: UserType,
            args: {
                firstName: {type: new GraphQLNonNull(GraphQLString)},
                age:{type: new GraphQLNonNull(GraphQLInt)},
                companyId: {type: GraphQLString}
            },
            resolve(parentValue, {firstName, age}) {  
                //insert new users record
                return axios.post('http://localhost:8900/users' ,{firstName, age})
                .then(res => res.data)
            }
        }
    }
});

module.exports = new GraphQLSchema({ //export 
    query: RootQuery,
    mutation: mutation
});