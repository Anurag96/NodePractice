let chai = require('chai');                                      //import system defined chaai module
let chaiHttp  = require('chai-http');                            //import system defined chai-http module
let expect = chai.expect;                                        //select expect style
chai.use(chaiHttp);                                              //congif chai-http middleware for testing

describe('Testing  my Rest Api', () => {                         //block groups test cases
    it('should  return status 200 for /',function(done){         //unit test case
        chai
            .request('http://localhost:6500')                    //connect to this url  
            .get('/')                                            //connect to root route
            .then(function(res){                                 //then check for all ok HTTP status code 200 
                expect(res).to.have.status(200);
                done();                                          //done() signals call to next callback function
            })
            .catch(function(err){                                //error handler
                throw(err);
            })
    });

    it('should  return status 200 for /movies',function(done){  //unit test case
        chai
            .request('http://localhost:6500')                   //connect to this endpoint
            .get('/movies')                                     //connect to this route
            .then(function(res){                                //check for all ok HTTP status code 200
                expect(res).to.have.status(200);
                done();                                         //done() signals call to next callback function
            })
            .catch(function(err){                               //error handler
                throw(err)
            })
    });

    it('should return the status 404', function(done){        //unit test case     
        chai
            .request('http://localhost:6500')                 //connect to this end point
            .get('/movie')                                    //connect to this route
            .then(function(res){                              //check for url not found HTTP 404 status code
                expect(res).to.have.status(404);
                done();                                      //done() signals call to next callback function
            })
            .catch(function(err){                            //error handler
                throw(err);
            });
    });
})