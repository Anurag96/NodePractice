import fs from 'fs';                                //import system defined file system module
import express from 'express';                      //import system defined express module
const app = express();                              //initialize express 
const port = 6500;                                  //setup the port

app.get('/',(req,res)=>{                            //setup root express route
    res.send('<h1>Welcome to api For FS</h1>');     //return html string
});

app.get('/movies',(req,res) => {                   
    fs.readFile('db.json',(err,result) => {        //read json file 
        if(err) throw err;
        res.send(JSON.parse(result));              //send json data to the browser
    })
})

app.get('/mytext',(req,res) => {
    fs.readFile('myText.txt','utf-8',(err,data) => {//read text file 
        if(err) throw err;
        res.send(data);                             //send text data to the browser 
    })
})

app.get('/bothops',(req,res) => {
    fs.appendFile('./mytext2.txt','My text read file\n',(err) => { //append data to the text file
        if(err) throw err;
        else{
            fs.readFile('./mytext2.txt','utf-8',(err,data) => { //read data from the text file
                if(err) throw err;
                res.send(data);                    //send text data to the browser       
            })
        }
    })

})

app.listen(port,(err)=>{                          //express listening on the port
    console.log(`Server is running on port ${port}`)
})