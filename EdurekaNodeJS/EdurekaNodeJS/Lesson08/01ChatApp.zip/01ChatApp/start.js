require('@babel/register')({presets: ["@babel/preset-env"]});  //register babel 
module.exports = require('./app');                             //import custom app file