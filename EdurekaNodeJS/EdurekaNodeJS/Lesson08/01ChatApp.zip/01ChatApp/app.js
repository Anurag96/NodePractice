import express from 'express';                         //import system defined express module
import path from 'path';                               //import system defined path module   
import http from 'http';                               //import system defined http module

const LocalStorage = require('node-localstorage').LocalStorage; //import system defined local strg. module
let localStorage = new LocalStorage('./scratch');     //add ref to custom scratch folder to store 
const iplocate = require("node-iplocate");            //import sys module for geolocation data from IP addresses
const publicIp = require('public-ip');                //import system defined module to get external IP list
let io = require('socket.io');                        //import system defined socket.io  server module
let app = express();                                  //initialize express


// Add configure for ui(index.html) and port
app.configure(() => {
    app.set('port', 3000);                            //set  port
    app.use(express.static(path.join(__dirname, 'public')));//sreve static index.html file
});

app.configure('development', () => {                 //config express for dev env. 
    app.use(express.errorHandler());                 //throws errors to console
});

// Set up express port / server
let server = http.createServer(app).listen(app.get('port'), function(){
    console.log("Express server listening on port " + app.get('port'));
});

// Set up socket.io on the server side
io = require('socket.io').listen(server);


// Handle socket traffic
io.sockets.on('connection',  (socket) => {         //system defined event , fired when a new user connects

    var list = io.sockets.sockets;                 //create custom list sockets connected to the server          
    var users = Object.keys(list);                 //create custom users array users(sockets) logged in
   
    // Set the nickname property for a given client
    socket.on('nick', (nick) => {                  //custom event handler 'nick'
        socket.set('nickname', nick);              //assing the username of new chat user logged in
        socket.emit('userlist', users);            //fire custom userlist event on the client, pass list of users
    });

   

    // Broadcast the  chat message to all clients
    socket.on('chat', (data) => {                 //server side event handler that will be fired by the client
        socket.get('nickname', (err, nick) => {   //retreive nickname of user 
            publicIp.v4().then(ip => {            //retreive external IP of clients connected to server
                iplocate(ip).then(function(results) { //get the clients geolocation from their IP
                    let respo = JSON.stringify(results.city, null, 2); //convert city (geo data) to string
                    localStorage.setItem('userlocal',respo);           //set the city into localstorage  
               });
            });

            let nickname = err ? 'Anonymous' : nick; //set nickname to actual nick or 'Annoymous' if not found    

            let payload = {                         //initialize the message data to broadcast to all users
                message: data.message,
                nick: nickname,
                location:localStorage.getItem('userlocal')
            };

            socket.emit('chat',payload);           //fire this custom 'chat' event on the client 
            socket.broadcast.emit('chat', payload);//broadcast the event to send msg to all clients
        });
    });
});


