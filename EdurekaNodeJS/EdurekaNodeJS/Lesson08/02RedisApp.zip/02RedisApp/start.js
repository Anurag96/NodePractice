require('@babel/register')({presets: ["@babel/preset-env"]}); //config & resgiter babel for ES6 to ES5 support
module.exports = require('./src/app')                             //import user defines app file
