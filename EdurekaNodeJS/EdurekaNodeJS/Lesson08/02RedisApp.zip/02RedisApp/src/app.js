import express from 'express';                      //import system defined express module
import redis from 'redis';                          //import system defined redis module        
const app = express();                              //init express
const port = 8088;                                  //set port

//Connecting redis
const client = redis.createClient({                 //connect to redis-server thast running on port 6379
    host: '127.0.0.1',
    port: 6379
})

// default set zero
client.set('aprvisit', 0);                          //create a key in redis with data =0

// Default route
app.get('/',(req,res) => {                         //default express route
    client.get('aprvisit', (err,aprvisit )=> {     //get data using the key from redis-server
        client.set('aprvisit', parseInt(aprvisit)+1);//increment key data in redis-server by 1 
        res.send('Number of visit is'+aprvisit);   //send data to client html page
    });
});

app.listen(port,() => {                            //config express port, start express server
    console.log('app is running on port'+ port)
});