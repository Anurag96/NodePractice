const express = require('express');                          //import system defined express
const axios = require('axios');                              //import system defined axiois . Async api to call REST Srvc.

// Constants
const PORT = 8080;                                          //port
const HOST = '0.0.0.0';                                     //IP

const app = express();                                      //init express
const searchUrl = `https://restcountries.eu/rest/v2/all`;   //ready REST api

app.get('/', (req, res) => {                                //default route                    
  axios.get(searchUrl).then(response => {                   //connect in async mode to the REST api
    const responseJSON = response.data;                     //trap the response
    return res.status(200).json({ source: 'Docker Microservice', ...responseJSON, }); //send data to browser
  })
  .catch(err => {                                          //on err 
    return res.json(err);
  });
  
});

app.listen(PORT, HOST);                                    //start the server
console.log(`Running on http://${HOST}:${PORT}`);  