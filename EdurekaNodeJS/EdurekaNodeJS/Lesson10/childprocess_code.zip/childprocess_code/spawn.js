const fs = require('fs');                                     //import system define fs module
const child_process = require('child_process');               //import system defined child process module
 
for(var i = 0; i<3; i++) { //run thrice

   //create child process node=command to be executed by the process, text.js File  to be executed by that child process
   var workerProcess = child_process.spawn('node', ['test.js', i]);   

   //system defined data event on the child process. writes data when available
   workerProcess.stdout.on('data', function (data) {
      console.log('stdout: ' + data);
   });

    //system defined data event on the child process. writes error messages when available
   workerProcess.stderr.on('data', function (data) {
      console.log('stderr: ' + data);
   });

    //system defined close event on the child process. Closes the streams to the file test.js
   workerProcess.on('close', function (code) {
      console.log('child process exited with code ' + code);
   });
}