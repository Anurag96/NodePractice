const fs = require('fs');                             //import system define fs module
const child_process = require('child_process');        //import system defined child process module

for(var i=0; i<3; i++) {  //run thrice

   //create child process node=command to be executed by the process, text.js File  to be executed by that child process
   var workerProcess = child_process.exec('node test.js '+i,function //callback function
      (error, stdout, stderr) {
      
      if (error) { //on error
         console.log(error.stack);
         console.log('Error code: '+error.code);
         console.log('Signal received: '+error.signal);
      }
      console.log('stdout: ' + stdout);    //print data output by the child process
      console.log('stderr: ' + stderr);    //print err output by the child process
   });

   //system defined close event on the child process. Closes the streams to the file test.js
   workerProcess.on('exit', function (code) {
      console.log('Child process exited with exit code '+code);
   });
}