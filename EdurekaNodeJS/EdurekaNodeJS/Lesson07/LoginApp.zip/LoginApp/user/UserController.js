//Controller manages Listing Registered users  & Logout to remove jwt token
const express = require('express');                            //import system defined express module
const router = express.Router();                               //import express Router module
const bodyParser = require('body-parser');                     //import system defined body-parser module
const LocalStorage = require('node-localstorage').LocalStorage;//import system defined localstorage module 
const config = require('../config.js');                        //import user defined config 
const jwt = require('jsonwebtoken');                           //import system defined jwt module 
localStorage = new LocalStorage('./scratch');                  //import folder where jwt token is stored 

router.use(bodyParser.urlencoded({ extended: true }));         //register body-parser with express
router.use(bodyParser.json());                      
const User = require('./User');                                //import User conteollers



// GETS A SINGLE USER FROM THE DATABASE
    router.get('/profile', function (req, res) {                //express route for profile
        var token = localStorage.getItem('authtoken');          //get ref to the jwt token
        console.log("token>>>",token);                          //print token in the terminal  
        if (!token) {
            res.redirect('/');                                  //redirect to login page if no token found 
        }
        jwt.verify(token, config.secret, function(err, decoded) {//validate and decode the token and the user data 
        if (err) {
            res.redirect('/');                                   //if err on decoding, move to login page 
        };
            User.findById(decoded.id, { password: 0 }, function (err, user) {//find user in MongoDB
                if (err) {res.redirect('/')}                     //if error back to login page
                if (!user) {res.redirect('/')}                   //if user not found, back to login
                res.render('profile.ejs',{user});                //render the view with user info  
            });
        });
    });


 router.get('/logout', (req,res) => {                          //express route for logout
     localStorage.removeItem('authtoken');                     //delete token from localstorage / 'Scratch' folder
     res.redirect('/');                                        //navigate to login page
 })

module.exports = router;