const mongoose = require('mongoose');             //import system defined ORM

const UserSchema = new mongoose.Schema({          //define the schema
  name: String,
  email: String,
  password: String
});

mongoose.model('EduUser', UserSchema);            //associate the schema as the Entity Data Model with a custom Key

module.exports = mongoose.model('EduUser');       //Export the Entity Model Schema