const app = require('./app');                            //import custom app.ja
const express = require('express');                      //import system defined express
const port =  3000;                                      //define the port
const bodyParser =  require('body-parser');              //import body-parser
const session = require('express-session');              //import express-session  

app.use(express.static(__dirname+'/public'));            //register static content (js/css)

app.use(session({secret: 'edurekaSecert'}));             //define secret key for tokens

app.set('view engine', 'ejs');                           //register ejs middleware
app.set('views', './views');                             //set default ejs views folder

let sess;                                                //define tem variable  

app.get('/',(req,res) => {                               //default express route
    sess=req.session;                                    //set local variable with server created session
    sess.email=" ";                                      //blank email as no user has logged in
    console.log(">>>>",sess.email);                      
    res.render('index',{error: req.query.valid?req.query.valid:'',//pass error and msg parameter to view
                        msg: req.query.msg?req.query.msg:''})
});

app.get('/signup',(req,res) => {                        //signup route  
  res.render('signup')
})

const server = app.listen(port, () => {                //start server
  console.log('Express server listening on port ' + port);
});