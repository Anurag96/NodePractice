module.exports = {
    'secret': 'supersecret'                  //create custom secret key name and exporting it
  };
  