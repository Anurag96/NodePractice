//Controller manages User Registration and User Login
const express = require('express');           //import system defined express module
const router = express.Router();              //import system defined Express Router
const LocalStorage = require('node-localstorage').LocalStorage; //module stores data in HTML5 client local storage
localStorage = new LocalStorage('./scratch'); //initialize the localstorage module , pass custom class 
const app = express();                        //initialize express context
const bodyParser = require('body-parser');    //import system defined module, reads HTTP message body
const jwt = require('jsonwebtoken');          //import system defined JWT module for token generation
const bcrypt = require('bcryptjs');           //import system defined module for encrypting Password
const config = require('../config');          //import custom file that has the custom secret key name 
const User = require('../user/User');         //import custom file that has Mongoose Schema 
const session = require('express-session');   //import system defined module for sessions mgmt on express

//configure express router to use the session obj
router.use(session({secret: 'edurekaSecert1', resave: true, saveUninitialized: true}));
/*
saveUninitialized : Forces a session that is "uninitialized" to be saved to the store. 
                    A session is uninitialized when it is new but not modified. 
secret: This is the secret used to sign the session ID cookie. 
resave: Forces the session to be saved to the session store, even if the session was not modified during the request
*/

app.use(express.static(__dirname+'/public'));  //server static css/js files form public folder
app.set('view engine', 'ejs');                 //register ejs with express
app.set('views', './views');                   //set default ejs views folder

router.use(bodyParser.urlencoded({ extended: false })); //register body-parser with expresss router
router.use(bodyParser.json());                 //set body-parser data format      

router.post('/register', function(req, res) {  //express route to register a user
  
    const hashedPassword = bcrypt.hashSync(req.body.password, 8); //has password, 8 times
    
    User.create({                              //create new user object as per Mongoose schema
      name : req.body.name,
      email : req.body.email,
      password : hashedPassword                //assign hashed password to the user object
    },
    function (err, user) {                     //on success og user object creation
      if (err) return res.status(500).send("There was a problem registering the user.")
      
      var token = jwt.sign({ id: user._id }, config.secret, { // create a jwt token. Sign with secret token
        expiresIn: 86400                      //sets token expires in 24 hours
      });
      const string = encodeURIComponent('Successfully Registered. Please Login'); //encode custom string msg
      res.redirect('/?msg=' + string);        //construct the url query string msg='';
    }); 
  });


router.post('/login', function(req, res) {   //express route to Login an existing user
    User.findOne({ email: req.body.email }, function (err, user) {    //find the user email in the Mongo DB
      if (err) return res.status(500).send('Error on the server.');
      const string = encodeURIComponent('! Please enter valid value');//encode custom string msg 
      if (!user) { res.redirect('/?valid=' + string);}                //redirect with above msg on login faliure
      else{
        const passwordIsValid = bcrypt.compareSync(req.body.password, user.password); //validate hashed pwd
        if (!passwordIsValid) return res.status(401).send({ auth: false, token: null }); //nul token on pwd error
        var token = jwt.sign({ id: user._id }, config.secret, {      //on success login, create new jwt token & sign
            expiresIn: 86400                                         //sets token expiry to 24 hours
        });
        localStorage.setItem('authtoken', token);                    //store token in HTML% client local storage
        res.redirect(`/users/profile`);                              //redirect to profile view, post sucess login
      }
    });
});



module.exports = router;                                      //export 