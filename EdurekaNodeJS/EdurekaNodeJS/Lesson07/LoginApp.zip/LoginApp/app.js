const express = require('express');                        //import system define express
const app = express();                                     //initialize express context
const db = require('./db');                                //import user defined file

const UserController = require('./user/UserController');   //import user defined controller class
app.use('/users', UserController);                         //register controller with express

const AuthController = require('./auth/AuthController');   //import user defined controller class
app.use('/api/auth', AuthController);                      //register controller with express. url /api/auth 

module.exports = app;                                      //export class 