const express = require('express'); //import express
const app = express();              //initialize express
const request = require('request'); //import request
const port = 5400;                  //set port

const weatherUrl = "http://api.openweathermap.org/data/2.5/forecast/daily?q=London&mode=json&units=metric&cnt=5&appid=fbf712a5a83d7305c3cda4ca8fe7ef29";

// Static file path to include bootstrat and css static files
app.use(express.static(__dirname+'/public'));
// Html or rending Path . Default Views folder path modified to src/views
app.set('views', './src/views');
// View engine specification added to express
app.set('view engine', 'ejs');



function getWeather(url) {  //custom method to set URL and header
    // Setting URL and headers for request
    var options = {
        url: weatherUrl,
        headers: {
            'User-Agent': 'request'
        }
   };
   //Return new promise 
    return new Promise(function(resolve, reject) {
        // Do async job
        request.get(options, function(err, resp, body) {
            if (err) {
                reject(err);
            } else {
                resolve(body);
            }
        })
    });
}

// Weather Api Route
app.get('/',(req,res) => {
    var dataPromise = getWeather(); //call the custom getWeather() function that sets up the url and header

    dataPromise.then(JSON.parse)    //then parse the data returned form the REST API in JSOn format
               .then(function(result) {
                    res.render('main',{result,title:'***Weather App***'}) ; //pass the data retreived to main.ejs
                })
});

//Weather Api Without promise
app.get('/weatherwithoutpromise',(req,res) => { //retreives the data from the REST API , without Promise
    request(weatherUrl, (err,response,body) =>{  //via callback
        if(err){
            console.log(err);
        } else {
           
            const output = JSON.parse(body);
            res.send(output);
        }
    });
});

app.listen(port ,(err) => {                                  //server listening on port 5400
    if(err) { console.log('error in api call')}
    else{ console.log ('App is running on port '+port)}
});